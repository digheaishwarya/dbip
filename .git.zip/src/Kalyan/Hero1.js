import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button,
  Typography,
  Grid
} from '@material-ui/core';

const useStyles = makeStyles((theme) => ({
  root: {
    flexDirection: 'column',
    alignItems: 'center',
    position: 'relative',
    width: '100%',
    height: '100%', // Set container height to 100vh (100% of viewport height)
    display: 'flex', // Assuming you want to use flexbox layout
    zIndex: -1,
    backgroundSize: 'cover',
    backgroundRepeat: 'no-repeat',
    backgroundPosition: 'right center',
    backgroundImage: 'url(https://images.top10.com/f_auto,fl_progressive:semi,q_auto/v1/production/charts/uploads/photo/BGC_DT_H.20240131143621.jpg)',
    [theme.breakpoints.down('sm')]: {
      // Adjust background position for smaller screens if needed
      backgroundPosition: 'center',
    },
  },

   title:{
    boxSizing: 'border-box',
    margin: 0,
    minWidth: 0,
    padding: 0,
    fontFamily: 'hurmegeometricsans_no3_6, Gilroy, Almarai, Arial, sans-serif',
    overflow: 'hidden',
    display: 'block',
    maxWidth: 700,
    lineHeight: '36px',
    color: '#ffffff',
    fontSize: 28,
    fontWeight:"00px",
    letterSpacing: '-0.1px',
    [theme.breakpoints.up('sm')]: {
      marginTop: 40,
    },
   },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  button: {
    margin: theme.spacing(2),
  },
  subtitle:{
    margin: 0,
    fontFamily: 'hurmegeometricsans_no3_6, Gilroy, Almarai, Arial, sans-serif',
    fontWeight: 400,
    lineHeight: '28px',
    fontSize: 18,
    letterSpacing: '-0.1px',
    color: '#FFFFFF',
    maxWidth: 700,
    [theme.breakpoints.up('sm')]: {
      marginTop: 20,
      marginBottom: 'unset',
      width: 'unset',
      display: 'block',
      WebkitLineClamp: 'unset',
      WebkitBoxOrient: 'unset',
    },
  },
  
}));

const Hero1 = () => {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      <Grid item xs={12} lg={8}>
      <Typography variant="h4" className={classes.title}>Best Background Check Services of 2024</Typography>
      <Typography variant="subtitle1" className={classes.subtitle}>Search people, social media posts, public records and the deep web <br></br>to arm yourself with information—quickly and easily.</Typography>
      <FormControl className={classes.formControl}>
        <TextField
          
          // Add necessary props and event handlers
        />
      </FormControl>
      <FormControl className={classes.formControl}>
        <TextField

          // Add necessary props and event handlers
        />
      </FormControl>
      <FormControl className={classes.formControl}>
        <InputLabel id="state-label">State</InputLabel>
        <Select
         
        >
          {/* Render menu items for each state */}
          <MenuItem value="">All States</MenuItem>
          {/* Add other states dynamically */}
        </Select>
      </FormControl>
      <Button
        
        className={classes.button}
        // Add necessary props and event handlers
      >
        Search Now
      </Button>
      </Grid>
    </div>
  );
};

export default Hero1;
